#!/bin/sh
clear
python Cythonize_ArmModel.py build_ext --inplace
python runTest.py 
